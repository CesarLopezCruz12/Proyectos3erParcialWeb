<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="test.css">
    <title>Test</title>
</head>
<body>

    <div id="test">
    <h1 id="title">Test</h1>

    <?php
        $preguntas=[
            "Presto mucha atención a los sentimientos.",
            "Normalmente me preocupo por lo que siento.",
            "Normalmente dedico tiempo a pensar en mis emociones.",
            "Pienso que merece la pena prestar atención a mis emociones.",
            "Dejo que mis sentimientos afecten a mis pensamientos.",
            "Pienso en mi estado de ánimo constantemente.",
            "A menudo pienso en mis sentimientos.",
            "Presto mucha atención a cómo me siento.",
            "Tengo claros mis sentimientos.",
            "Frecuentemente puedo definir mis sentimientos.",
            "Casi siempre sé cómo me siento.",
            "Normalmente conozco mis sentimientos sobre las personas.",
            "A menudo me doy cuenta de mis sentimientos en diferentes situaciones.",
            "Siempre puedo decir cómo me siento.",
            "A veces puedo decir cuáles son mis emociones.",
            "Puedo llegar a comprender mis sentimientos.",
            "Aunque a veces me siento triste, suelo tener una visión positiva.",
            "Aunque me sienta mal, procuro pensar en cosas agradables.",
            "Cuando estoy triste, pienso en todos los placeres de la vida.",
            "Intento tener pensamientos positivos aunque me sienta mal.",
            "Si doy demasiadas vueltas a las cosas, complicándolas, trato de calmarme.",
            "Me preocupo por tener un buen estado de ánimo.",
            "Tengo mucha energía cuando me siento feliz.",
            "Cuando estoy enfadado intento cambiar mi estado de ánimo."
        ];

        echo "<form action=\"resultados.php\" method=\"post\">";
        echo "<table align=center>";
        echo "<tr>";
        echo "<td>";
        echo "<label>Hombre</label><input type=\"checkbox\" name=\"Hombre\" value=\"H\"> ";
        echo "<label>Mujer</label><input type=\"checkbox\" name=\"Mujer\" value=\"M\"><br><br><br> ";
        echo "</td>";
        echo "</tr>";
        echo "</table>";
        echo "<table border=1 align=center>";
        for ($i=0; $i < 24 ; $i++) { 
            echo "<tr>";
            echo "<td>";
            echo $preguntas[$i];
            echo "</td>";
            echo "<td>";
            echo " <label> <input type=\"radio\" id=\"switch\" name=\"resultado[$i]\" value=1 /> <span> 1 </span> </label>  ";
            echo "</td>";
            echo "<td>";
            echo "<label> <input type=\"radio\" id=\"switch\" name=\"resultado[$i]\" value=2 /> <span> 2 </span> </label>   ";
            echo "</td>";
            echo "<td>";
            echo "<label> <input type=\"radio\" id=\"switch\" name=\"resultado[$i]\" value=3 /> <span> 3 </span> </label>   ";
            echo "</td>";
            echo "<td>";
            echo "<label> <input type=\"radio\" id=\"switch\" name=\"resultado[$i]\" value=4 /> <span> 4 </span> </label>   ";
            echo "</td>";
            echo "<td>";
            echo "<label> <input type=\"radio\" id=\"switch\" name=\"resultado[$i]\" value=5 /> <span> 5 </span> </label>    ";
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "<br><br><input type=\"submit\" id=\"button\" value=\"Enviar datos\">";
        echo "</form>";
        echo "</div>";
    ?>
</body>
</html>