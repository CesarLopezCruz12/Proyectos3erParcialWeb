<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados</title>
    <link rel="stylesheet" href="resultados.css">
</head>
<body>
<a href="http://localhost/Proyecto_Final/Instrucciones.php"><button type="button" class="btn btn-secondary">Regresar al Men&uacute; de Test</button></a>

    <?php

    error_reporting(0);

    $atencion=0;
    $claridad=0;
    $reparacion=0;
    $resultado=$_POST['resultado'];
    $total=0;
    $i = 0;

        echo "<div id=\"respuestas\">";
        echo "<h1 id=\"title\">Resultados:</h1>";
    
        if(isset($_REQUEST['Hombre'])){
            echo "<p>El genero selecionado es hombre</p>";
            for ($i; $i < 25 ; $i++) { 
                    $total += $resultado[$i];
                        if($i == 8){
                            if($total <= 21){
                                echo "<h2>Atenci&oacute;n</h2>";
                                echo "<p> Debes mejorar tu atencion: prestas poca antencion </p>";
                            }else if($total >=22 && $total<=32 ){
                                echo "<h2>Atenci&oacute;n</h2>";
                                echo "<p> Prestas poca antencion </p>";
                            }else{
                                echo "<h2>Atenci&oacute;n</h2>";
                                echo "<p> Debes mejorar tu atencion: prestas demasiada antencion </p>";
                            }

                            $total2 = $total;

                        }
                        if($i == 16){
                            if($total - $total2 <=25){
                                echo "<h2>Claridad</h2>";
                                echo "<p> Debes mejorar tu claridad </p>";
                            }else if($total - $total2 >=26 && $total - $total2 <=35){
                                echo "<h2>Claridad</h2>";
                                echo "<p> Atencion adecuada </p>";
                            }else{
                                echo "<h2>Claridad</h2>";
                                echo "<p> Excelente claridad </p>";
                            }

                            $total3 = $total;

                        }
                        if($i == 24){
                            if($total - $total3 <=23){
                                echo "<h2>Reparaci&oacute;n</h2>";
                                echo "<p> Debes mejorar tu Reparaci&oacute;n </p>";
                            }else if($total - $total3 >=24 && $total - $total3 <=35){
                                echo "<h2>Reparaci&oacute;n</h2>";
                                echo "<p> Atencion adecuada </p>";
                            }else{
                                echo "<h2>Reparaci&oacute;n</h2>";
                                echo "<p> Excelente Reparaci&oacute;n </p>";
                            }
                        }
            }

            echo "<p>Resultado: $total</p>";

        }else if(isset($_REQUEST['Mujer'])){
            echo "<p>El genero selecionado es mujer</p>";
            for ($i; $i < 25 ; $i++) { 
                $total += $resultado[$i];
                    if($i == 8){
                        if($total <= 24){
                            echo "<h2>Atenci&oacute;n</h2>";
                            echo "<p> Debes mejorar tu atencion: prestas poca antencion </p>";
                        }else if($total >=25 && $total<=35 ){
                            echo "<h2>Atenci&oacute;n</h2>";
                            echo "<p> Prestas poca antencion </p>";
                        }else{
                            echo "<h2>Atenci&oacute;n</h2>";
                            echo "<p> Debes mejorar tu atencion: prestas demasiada antencion </p>";
                        }

                        $total2 = $total;

                    }
                    if($i == 16){
                        if($total - $total2 <=23){
                            echo "<h2>Claridad</h2>";
                            echo "<p> Debes mejorar tu claridad </p>";
                        }else if($total - $total2 >=24 && $total - $total2 <=34){
                            echo "<h2>Claridad</h2>";
                            echo "<p> Atencion adecuada </p>";
                        }else{
                            echo "<h2>Claridad</h2>";
                            echo "<p> Excelente claridad </p>";
                        }

                        $total3 = $total;

                    }
                    if($i == 24){
                        if($total - $total3 <=23){
                            echo "<h2>Reparaci&oacute;n</h2>";
                            echo "<p> Debes mejorar tu Reparaci&oacute;n </p>";
                        }else if($total - $total3 >=24 && $total - $total3 <=34){
                            echo "<h2>Reparaci&oacute;n</h2>";
                            echo "<p> Atencion adecuada </p>";
                        }else{
                            echo "<h2>Reparaci&oacute;n</h2>";
                            echo "<p> Excelente Reparaci&oacute;n </p>";
                        }
                    }
        }

        echo "<p>Resultado: $total</p>";

        }else{
            echo "<p>No se seleciono genero</p>";

        }

       
    echo "</div>";
    ?>
    
</body>
</html>