<html>

<head>
	<title>Presentacion</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body style="background-image: url(https://mdbootstrap.com/img/Photos/Others/background.jpg);">

	<div class="container my-5 px-0 z-depth-1">
		<section class="text-center white-text grey p-5">
			<div class="row d-flex justify-content-center">
				<div class="col-md-6">
					<h3 class="font-weight-bold">Proyecto final del 3er Parcial</h3>
					<h6>Para este ultimo Parcial de la asignatura de de Desarrollo Web, se nos pidio hacer una pagina web la cual fuera capaz de almacenar todos los test y de esta forma acceder a cada uno de ellos, claro que los test a los que se nos envia son a los mismos que nuestro grupo ha hecho a lo largo del semestre, por lo que se podria decir que es un proyuecto grupal</h6>
					Integrantes
					<ol>
						<li>Flores Jimenez Octavio</li>
						<li>Gac&iacute;a Cer&oacute;n Diego</li>
						<li>L&oacute;pez Cruz Cesar</li>
						<li>Rivera Jacome Jocsan</li>
					</ol>
					<a href="Instrucciones.php"><button type="button" class="btn btn-primary">Ir al menu de los Test</button></a>

				</div>
		</section>
	</div>
</body>

</html>