jQuery(document).ready(function ($) {
	
	$("#T1").change(function() {
		
		var totalS   = 0,totalN = 0;
        
		$('input[value=S1]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalS ++;
            }
        });
		$('input[value=N1]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalN ++;
            }
        });

		$("#T1s span").text(totalS);	
		$("#T1n span").text(totalN);		
	});
	$("#T2").change(function() {
		
		var totalS   = 0,totalN = 0;
        
		$('input[value=S2]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalS ++;
            }
        });
		$('input[value=N2]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalN ++;
            }
        });

		$("#T2s span").text(totalS);	
		$("#T2n span").text(totalN);		
	});
	$("#T3").change(function() {
		
		var totalS   = 0,totalN = 0;
        
		$('input[value=S3]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalS ++;
            }
        });
		$('input[value=N3]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalN ++;
            }
        });

		$("#T3s span").text(totalS);	
		$("#T3n span").text(totalN);		
	});
	$("#T4").change(function() {
		
		var totalS   = 0,totalN = 0;
        
		$('input[value=S4]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalS ++;
            }
        });
		$('input[value=N4]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalN ++;
            }
        });

		$("#T4s span").text(totalS);	
		$("#T4n span").text(totalN);		
	});
	$("#T5").change(function() {
		
		var totalS   = 0,totalN = 0;
        
		$('input[value=S5]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalS ++;
            }
        });
		$('input[value=N5]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalN ++;
            }
        });

		$("#T5s span").text(totalS);	
		$("#T5n span").text(totalN);		
	});
	
	$("#T6").change(function() {
		
		var totalS   = 0,totalN = 0;
        
		$('input[value=S6]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalS ++;
            }
        });
		$('input[value=N6]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalN ++;
            }
        });

		$("#T6s span").text(totalS);	
		$("#T6n span").text(totalN);		
	});

	$("#T7").change(function() {
		
		var totalS   = 0,totalN = 0;
        
		$('input[value=S7]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalS ++;
            }
        });
		$('input[value=N7]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalN ++;
            }
        });

		$("#T7s span").text(totalS);	
		$("#T7n span").text(totalN);		
	});

	$("#T8").change(function() {
		
		var totalS   = 0,totalN = 0;
        
		$('input[value=S8]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalS ++;
            }
        });
		$('input[value=N8]').each( function() {
            if( $(this).is(':checked') ) {
              
				totalN ++;
            }
        });

		$("#T8s span").text(totalS);	
		$("#T8n span").text(totalN);		
	});
});

