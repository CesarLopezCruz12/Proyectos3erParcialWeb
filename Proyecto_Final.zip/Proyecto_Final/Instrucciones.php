<html>

<head>
	<title>Bienvenido al Menu de los Test</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body style="background-image: url(https://mdbootstrap.com/img/Photos/Others/background.jpg);">

	<div class="container my-5 px-0 z-depth-1">
		<section class="text-center white-text grey p-5">
				<div class="col-md-6">
					<h3 class="font-weight-bold">Menu de Test</h3>
					<ol>
						<li>Chaside </li>
						<a href="ProyectoChaside/Instrucciones.php"><button type="button" class="btn btn-primary">Ir a las Intrucciones</button></a>
						<li>Inventariado de motivacion personal </li>
						<a href="3 inventario de la motivacion personal/Index.php"><button type="button" class="btn btn-primary">Ir a las Intrucciones</button></a>
						<li>Heme </li>
						<a href="Cuestionario_Hema_y_Datos/rules.html"><button type="button" class="btn btn-primary">Ir a las Intrucciones</button></a>
						<li>Test de inteligencia Emocional 1 </li>
						<a href="Practicaweb/index.php"><button type="button" class="btn btn-primary">Ir a las Intrucciones</button></a>
						<li>Test de inteligencia Emocional 2 </li>
						<a href="TestEmocional/instrucciones.html"><button type="button" class="btn btn-primary">Ir a las Intrucciones</button></a>
						<li>Autoestima </li>
						<a href="Test de autoestima/instruTest(inicio).html"><button type="button" class="btn btn-primary">Ir a las Intrucciones</button></a>
						<li>Asertividad </li>
						<a href="testAsertividad/intro.html"><button type="button" class="btn btn-primary">Ir a las Intrucciones</button></a>
					</ol>
				</div>
		</section>
	</div>
</body>

</html>