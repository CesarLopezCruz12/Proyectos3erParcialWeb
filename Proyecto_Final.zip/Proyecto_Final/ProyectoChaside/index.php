<html>

<head>
	<title>Presentacion</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body style="background-image: url(https://mdbootstrap.com/img/Photos/Others/background.jpg);">

	<div class="container my-5 px-0 z-depth-1">
		<section class="text-center white-text grey p-5">
			<div class="row d-flex justify-content-center">
				<div class="col-md-6">
					<h3 class="font-weight-bold">Proyecto 3er Parcial</h3>

					Integrantes
					<ol>
						<li>Flores Jimenez Octavio</li>
						<li>Gac&iacute;a Cer&oacute;n Diego</li>
						<li>L&oacute;pez Cruz Cesar</li>
						<li>Rivera Jacome Jocsan</li>
					</ol>
					<a href=""><button type="button" class="btn btn-secondary">Regresar al Men&uacute;</button></a>
					<a href="Instrucciones.php"><button type="button" class="btn btn-primary">Ir a las Intrucciones</button></a>
				</div>
		</section>
	</div>
</body>

</html>