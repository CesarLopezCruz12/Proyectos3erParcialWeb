<html>
	<head>
		<title>Intrucciones</title>
	<head>
	<body>
		<h1><p>Chaside</p></h1>
		<p>El Test Chaside, es un test de orientación vocacional desarrollado por el doctor Holland. Es una herramienta orientada a ayudarte a conocer cuál sería la decisión más acertada partiendo de tus intereses, habilidades y/o preferencias</p>
		<button><a href="formulariotest.php">Iniciar Test</a></button>
		<a href="http://localhost/Proyecto_Final/Instrucciones.php"><button type="button" class="btn btn-secondary">Regresar al Men&uacute; de Test</button></a>
	</body>
</html>