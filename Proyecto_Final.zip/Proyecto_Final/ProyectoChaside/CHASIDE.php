<html>
	<head>
		<title>CHASIDE</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
	</head>
	
	<body>
	
	<?php
		$selected = '';
		$sumas = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		$celdas = array(
		array(98,12,64,53,85,1,78,20,71,91),
		array(9,34,80,25,95,67,41,74,56,89),
		array(21,45,96,57,28,11,50,3,81,36),
		array(33,92,70,8,87,62,23,44,16,52),
		array(75,6,19,38,60,27,83,54,47,97),
		array(84,31,48,73,5,65,14,37,58,24),
		array(77,42,88,17,93,32,68,49,35,61),
		array(0,0,0,0,0,0,15,51,2,46),
		array(0,0,0,0,0,0,63,30,72,86),
		array(0,0,0,0,0,0,22,39,76,82),
		array(0,0,0,0,0,0,69,40,29,4),
		array(0,0,0,0,0,0,26,59,90,10),
		array(0,0,0,0,0,0,13,66,18,43),
		array(0,0,0,0,0,0,94,7,79,55)
		);
		$total = count($celdas);
		for ($i = 0; $i < $total; $i++) {
			for ($j = 0; $j <= 9; $j++){
				foreach($_GET['valores'] as $key => $value){
					if ($value == $celdas[$i][$j]) {
						$sumas[$i] = $sumas[$i] + $celdas[$i][$j];
					}
				}
			}
		}
			
		/*
		echo "<script type='text/javascript'>
						console.log('n$value');
						var celda = document.getElementById('n$value');
						console.log(document.getElementById('n$value'));
						celda.setAttribute('style', 'background-color: red;');
					</script>";
		*/
	?>
	<div class="row">
		<div class="col-md-2 offset-md-2">
			<a href='formulariotest.php'><button  class="btn btn-info">Regresar a preguntas</button></a>
		</div>
	</div>
	<hr>
	
		<div div class="row">
			<div div class="row">
				<div class="col-md-4 offset-md-2">
					<table class="table table-striped">
						<tr>
							<td>C</td>
							<td>H</td>
							<td>A</td>
							<td>S</td>
							<td>I</td>
							<td>D</td>
							<td>E</td>
						</tr>
						<tr>
							<td>98</td>
							<td>9</td>
							<td>21</td>
							<td>33</td>
							<td>75</td>
							<td>85</td>
							<td>77</td>
						</tr>
						<tr>
							<td>12</td>
							<td>34</td>
							<td>45</td>
							<td>92</td>
							<td>6</td>
							<td>31</td>
							<td>42</td>
						</tr>
						<tr>
							<td>64</td>
							<td>80</td>
							<td>96</td>
							<td>70</td>
							<td>19</td>
							<td>48</td>
							<td>88</td>
						</tr>
						<tr>
							<td>53</td>
							<td>25</td>
							<td>57</td>
							<td>8</td>
							<td>38</td>
							<td>73</td>
							<td>17</td>
						</tr>
						<tr>
							<td>85</td>
							<td>95</td>
							<td>28</td>
							<td>87</td>
							<td>60</td>
							<td>5</td>
							<td>93</td>
						</tr>
					</table>
				</div>
			</div>
			<div class="row">
				<div class="col-md-8 offset-md-2">
					<table class="table table-striped">
						<tr>
							<td>1</td>
							<td>67</td>
							<td>11</td>
							<td>62</td>
							<td>27</td>
							<td>65</td>
							<td>32</td>
							<td>C</td>
							<td>H</td>
							<td>A</td>
							<td>S</td>
							<td>I</td>
							<td>D</td>
							<td>E</td>
						</tr>
						<tr>
							<td>78</td>
							<td>41</td>
							<td>50</td>
							<td>23</td>
							<td>83</td>
							<td>14</td>
							<td>68</td>
							<td>15</td>
							<td>63</td>
							<td>22</td>
							<td>69</td>
							<td>26</td>
							<td>13</td>
							<td>94</td>
						</tr>
						<tr>
							<td>20</td>
							<td>74</td>
							<td>3</td>
							<td>44</td>
							<td>54</td>
							<td>37</td>
							<td>49</td>
							<td>51</td>
							<td>30</td>
							<td>39</td>
							<td>40</td>
							<td>59</td>
							<td>66</td>
							<td>7</td>
						</tr>
						<tr>
							<td>71</td>
							<td>56</td>
							<td>81</td>
							<td>16</td>
							<td>47</td>
							<td>68</td>
							<td>35</td>
							<td>2</td>
							<td>72</td>
							<td>76</td>
							<td>29</td>
							<td>90</td>
							<td>18</td>
							<td>79</td>
						</tr>
						<tr>
							<td>91</td>
							<td>89</td>
							<td>36</td>
							<td>52</td>
							<td>97</td>
							<td>24</td>
							<td>61</td>
							<td>46</td>
							<td>86</td>
							<td>82</td>
							<td>4</td>
							<td>10</td>
							<td>43</td>
							<td>55</td>
						</tr>
					</table>
				<div>
			</div>
			<div class="row">
				<div class="col-md-13 offset-md-0">
			<?php
				echo "
				No. Respuestas
						<table class='table table-striped'> 
						<tr>";
					for ($i = 0; $i < 14; $i++) {
						echo "<td>$sumas[$i]</td>";
					}
				echo"		
					</tr>
				</table>";

			?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-8 offset-md-2">
					<table class="table table-dark">
						<thead class="thead-light">
							<tr>
								<th scope="col"></th>
								<th scope="col">Intereses</th>
								<th scope="col">Aptitudes</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th scope="row">C.- <br>
									Administrativas y Contables
								</th>
								<td>Organizativo, Supervisi&oacute;n, Orden, An&aacute;lisis y S&iacute;ntesis, Colaboraci&oacute;n, C&aacute;lculo</td>
								<td>Persuasivo, Objetivo, Pr&aacute;ctivo, Tolerante, Responsable, Ambicioso</td>
							</tr>
							<tr>
								<th scope="row">H.-<br>
									Human&iacute;stico y Social
								</th>
								<td>Precisi&oacute;n verbal, Organizaci&oacute;n, Relaci&oacute;n de Hechos, Ling&uuml;&iacute;stica, Orden, Justicia</td>
								<td>Responsable, Justo, Conciliador, Persuasivo, Sagaz, Imaginativo</td>
							</tr>
							<tr>
								<th scope="row">A.- <br>
									Art&iacute;sticas
								</th>
								<td>Est&eacute;tico, Arm&oacute;nico, Manual, Visual, Auditivo</td>
								<td>Sensible, Imaginativo, Creativo, Detallista, Innovador, Intuitivo</td>
							</tr>
							<tr>
								<th scope="row">S.- <br>
									Medicina y Ciencias de la Salud
								</th>
								<td>Asistir, Investigativo, Presici&oacute;n, Senso-Perceptivo Anal&iacute;tico, Ayudar</td>
								<td>Altruista, Solidario, Paciente, Comprensivo, Respetuoso, Persuasivo</td>
							</tr>
							<tr>
								<th scope="row">I.- <br>
									Ingenieri&iacute;a y Computaci&oacute;n
								</th>
								<td>C&aacute;lculo, Cien&iacute;fico, Manual, Exacto</td>
								<td>Preciso, Pr&aacute;ctico, Cr&iacute;tico, Anal&iacute;tico, R&iacute;gidoSS</td>
							</tr>
							<tr>
								<th scope="row">D.- <br>
								Defensa y Seguridad
								</th>
								<td>Justicia, Equidad,Colaboraci&oacute;n Esp&iacute;ritu de equipo, Liderazgo</td>
								<td>Arriesgado, Solidario, Valiente, Agresivo, Persuasivo</td>
							</tr>
							<tr>
								<th  scope="row">E.- <br>
								Ciencias exactas y agrarias
								</th>
								<td>Clasificar, Num&eacute;rico, An&aacute;lisis, y S&iacute;ntesis, Organizaci&oacute;n, Orden, Investigaci&oacute;n</td>
								<td>Met&oacute;dico, Anal&iacute;tico, Observador, Introvertido, Paciente, Seguro</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			
				<div class="col-md-8 offset-md-2">
					<table class="table">
						<thead class="thead-light">
							<tr>
								<th scope="col">&Aacute;reas (CHASIDE)</th>
								<th scope="col">PROFESIONES</th>
							</tr>
						</thead>
						<tr>
							<td>A - ART&Iacute;STCIAS CREATIVAS Y ARTES</td>
							<td>Diseño gr&aacute;fico, diseño y decoraci&oacute;n de interiores, diseño de jardines, diseño de modas, diseño de joyas, artes pl&aacute;sticas, (pinturas, estructuras, danza, teatro y artesan&iacute;as), dibujo publicitario, restauraci&oacute;n, museolog&iacute;a, modelaje, fotograf&iacute;a, fotograf&iacute;a digital, gesti&oacute;n gr&aacute;fica y publicitaria, locuci&oacute;n y publicidad, actuaci&oacute;n y camarograf&iacute;a, arte industrial, producci&oacute;n audiovisual, multimedia, comunicaci&oacute;n y producci&oacute;n en radio y televisi&oacute;n, diseño de paisaje, cine y video, comunicaci&oacute;n esc&eacute;nica para televisi&oacute;n.</td>
						</tr>
						<tr>
							<td>H- HUMAN&Iacute;STICAS Y SOCIALES</td>
							<td>Psicolog&iacute;a en general, trabajo social, idiomas, educaci&oacute;n internacional, hist&oacute;rica y geogr&aacute;fica, periodismos, periodismo digital, derecho, ciencia, pol&iacute;tica, sociolog&iacute;a, antropolog&iacute;a, arqueolog&iacute;a, gesti&oacute;n social y desarrollo, consejer&iacute;a familiar, comunicaci&oacute;n y publicidad. Administraci&oacute;n educativa, educaci&oacute;n especial, psicopedagog&iacute;a, estimulaci&oacute;n temprana, traducci&oacute;n simult&aacute;nea, lingü&iacute;stica, educaci&oacute;n de p&aacute;rvulos, bibliotecas, museolog&iacute;a, relaciones internacionales y diplomacia, comunicaci&oacute;n social menci&oacute;n marketing y gesti&oacute;n de empresas, redacci&oacute;n creativa y publicitaria, relaci&oacute;n p&uacute;blica y comunicaci&oacute;n organizacional: hoteler&iacute;a y turismo, teolog&iacute;a industrial</td>
						</tr>
						<tr>
							<td>C- ADMINISTRATIVAS, CONTABLES, ECON&Oacute;MICAS Y FINANCIERAS</td>
							<td>Administraci&oacute;n de empresas, contabilidad, auditor&iacute;a, ventas, marketing estrat&eacute;gico, gesti&oacute;n y negocios internacionales, gesti&oacute;n empresarial, gesti&oacute;n financiera, ingenier&iacute;a comercial, comercio exterior, banca y finanzas, gesti&oacute;n de rrhh, comunicaci&oacute;n integradas en marketing, administraci&oacute;n de empresas, ecoturismo y hospitalidad, ciencia econ&oacute;micas y financieras. Administraci&oacute;n de ciencias p&uacute;blicas, ciencias empresariales, comercio electr&oacute;nico, emprendedores, gesti&oacute;n de organismos p&uacute;blicos (municipios, ministerios, etc.) gesti&oacute;n de centros educativos.</td>
						</tr>
						<tr>
							<td>D- DEFENSA Y SEGURIDAD<br>
								I- INGENIER&Iacute;A Y COMPUTACI&Oacute;N<br>
								E- CIENCIAS EXACTAS Y AGRARIAS
							</td>
							<td>Ingenier&iacute;a en sistemas computacionales, geolog&iacute;a, ingenier&iacute;a civil, arquitectura, electr&oacute;nica, telem&aacute;tica, telecomunicaciones, ingenier&iacute;a mecatr&oacute;nica, (rob&oacute;tica), imagen y sonidos, minas y petr&oacute;leos, metalurgia, ingenier&iacute;a mec&aacute;nica, ingenier&iacute;a industrial, f&iacute;sica matem&aacute;tica, ingenier&iacute;a en estad&iacute;stica, ingenier&iacute;a automotriz, biotecnolog&iacute;a ambiental, ingenier&iacute;a geogr&aacute;fica, carreras militares (marina, aviaci&oacute;n, ej&eacute;rcito) ingenier&iacute;a en costas y obras portuarias, estad&iacute;stica, inform&aacute;tica, desarrollo de sistemas, tecnolog&iacute;a de inform&aacute;tica educativa, astronom&iacute;a, ingenier&iacute;a en ciencias geogr&aacute;ficas y desarrollo sustentable.</td>
						</tr>
						<tr>
							<td>S- MEDICINA CIENCIAS DE LA SALUD, ECOL&Oacute;GICAS Y BIOL&Oacute;GICAS </td>
							<td>Biolog&iacute;a, Bioqu&iacute;mica, Farmacia, Biolog&iacute;a Marina, Bioan&aacute;lisis, Biotecnolog&iacute;a, Ciencias Ambientales, Zootecnia, Veterinaria, Nutrici&oacute;n y Est&eacute;tica,
								Cosmetolog&iacute;a, Diet&eacute;tica y Est&eacute;tica, Medicina, Obstetricia, Urgencias M&eacute;dicas, Odontolog&iacute;a, Enfermer&iacute;a, Tecnolog&iacute;a, Oceanograf&iacute;a y Ciencias
								Ambientales, M&eacute;dica, Agronom&iacute;a, Horticultura y Fruticultura, Ingenier&iacute;a de Alimentos, Gastronom&iacute;a, Chef, Cultura F&iacute;sica, Deportes y
								Rehabilitaci&oacute;n, Gesti&oacute;n Ambiental, Ingenier&iacute;a Ambiental, Optometr&iacute;a, Homeopat&iacute;a, Reflexolog&iacute;a.
							</td>
						</tr>
					</table>
					<a href="http://localhost/Proyecto_Final/Instrucciones.php"><button type="button" class="btn btn-secondary">Regresar al Men&uacute; de Test</button></a>

					</div>
				</div>
			</div>
		</div>
	</body>
</html>