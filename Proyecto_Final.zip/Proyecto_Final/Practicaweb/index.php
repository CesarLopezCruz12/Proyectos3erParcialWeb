<?php

require_once "controllers/controller.php";
require_once "models/modelo.php";



$mvc = new MvcController();
$mvc -> plantilla();

?>