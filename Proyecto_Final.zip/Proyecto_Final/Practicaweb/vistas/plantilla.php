<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Template</title>
    <link rel="stylesheet" href="https://unpkg.com/@picocss/pico@latest/css/pico.min.css" />

</head>
<body>
<style>
    td{
        border-left: 1px solid black;
    }
    table{
        border-collapse: collapse;
    }
</style>
<header>

    <h1>Test de inteligencia emocional</h1>

</header>
<section>
    <?php

    if(isset($_GET["pagina"])){
                
    if ($_GET["pagina"] == "inicio" || 
        $_GET["pagina"] == "instrucciones" || 
        $_GET["pagina"] == "test" || 
        $_GET["pagina"] == "resultados" ||
        $_GET["pagina"] == "consulta"){
        include "vistas/modulos/".$_GET["pagina"].".php";
    }

    }else{

        include "vistas/modulos/inicio.php";

    }

    ?>
</section>

</body>
</html>