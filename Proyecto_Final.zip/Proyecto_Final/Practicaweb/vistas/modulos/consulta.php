<?php 
$host="localhost";
$user ="root";
$clave = "";
$db = "test";
$conexion=mysqli_connect($host,$user,$clave,$db);
?>

<table border="1">
    <tr>
        <td>nombre</td>
        <td>sexo</td>
        <td>correo</td>
        <td>resultado atencion</td>
        <td>resultado claridad</td>
        <td>resultado reparacion</td>
    </tr>

    <?php
    
        $sql="SELECT * from usuarios";
        $result=mysqli_query($conexion,$sql);

        while ($mostrar=mysqli_fetch_array($result)) {
            
        
    ?>

    <tr>
        <td><?php echo $mostrar['nombre'] ?></td>
        <td><?php echo $mostrar['sexo'] ?></td>
        <td><?php echo $mostrar['correo'] ?></td>
        <td><?php echo $mostrar['atencion'] ?></td>
        <td><?php echo $mostrar['claridad'] ?></td>
        <td><?php echo $mostrar['reparacion'] ?></td>
    </tr>
    <?php
        }
    ?>
</table>
<a href="index.php">Regresar</a>