El test de inteligencia emocional mide tres dimensiones clave:<br>
1.Autoconcimiento: Conocerse a uno mismo<br>
2.Autocontrol: Controlar los estados emocionales<br>
3.Autodireccion: Dirigir los estados emocionales<br>
<a href="index.php?pagina=instrucciones">Siguiente</a>

<br><a href="index.php?pagina=consulta">Ver registros</a>
<br><a href="index.php?pagina=resultados">Ver resultados</a>
<a href="http://localhost/Proyecto_Final/Instrucciones.php"><button type="button" class="btn btn-secondary">Regresar al Men&uacute; de Test</button></a>
