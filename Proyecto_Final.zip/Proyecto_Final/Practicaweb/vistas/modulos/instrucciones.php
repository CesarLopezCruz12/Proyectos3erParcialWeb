<h1>Instrucciones</h1>
<section>
    
El test de inteligencia emocional mide tres dimensiones clave:
<br>
1- Atención: Soy capaz de sentir y expresar los sentimientos de forma adecuada.
<br>
2- Claridad: Comprendo bien mis estados.
<br>
3- Reparación: Soy capaz de regular los estados emocionales correctamente.
<br>
Lee las siguientes afirmaciones sobre tus emociones y sentimientos e indica el grado de acuerdo o de desacuerdo con respecto a las mismas.
<br>
<table border="1">
    <tr>
        <td>1</td>
        <td>2</td>
        <td>3</td>
        <td>4</td>
        <td>5</td>
    </tr>
    <tr>
        <td>Nada de acuerdo</td>
        <td>Algo de acuerdo</td>
        <td>Bastante de acuerdo</td>
        <td>Muy de acuerdo</td>
        <td>Totalmente de acuerdo</td>
    </tr>
</table>
</section>
<a href="index.php?pagina=test">Hacer test</a>
<br><a href="index.php">Regresar</a>