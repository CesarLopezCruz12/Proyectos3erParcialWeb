<form method="post">
    <label>Nombre:</label>
    <input type="text" name="nom"><br>
    
    <button type="submit">Enviar</button><br>
    <?php

        $registro=MvcController::resultados();

    ?>
</form>

<a href="index.php">Regresar</a>