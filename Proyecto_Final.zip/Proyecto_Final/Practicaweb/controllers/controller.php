<?php

class MvcController{

    public function plantilla(){
        
        include "vistas/plantilla.php";
    }


    static public function captcha($label){
        if(isset($_POST["Rcaptcha"])){
    
            if ($_POST["Rcaptcha"] == $label) {
                return "ok";
            }else{
                echo'<script> alert("captcha incorrecto vuelve a intentar");
                        location.href="index.php";
                        </script>';
            }
        }
    }
    static public function test(){

        $host="localhost";
        $user ="root";
        $clave = "";
        $db = "test";
        $conectar=mysqli_connect($host,$user,$clave,$db);
        if(isset($_POST["Rnom"])){
        $p1=(int)$_POST["p1"];
        $p2=(int)$_POST["p2"];
        $p3=(int)$_POST["p3"];
        $p4=(int)$_POST["p4"];
        $p5=(int)$_POST["p5"];
        $p6=(int)$_POST["p6"];
        $p7=(int)$_POST["p7"];
        $p8=(int)$_POST["p8"];
        $p9=(int)$_POST["p9"];
        $p10=(int)$_POST["p10"];
        $p11=(int)$_POST["p11"];
        $p12=(int)$_POST["p12"];
        $p13=(int)$_POST["p13"];
        $p14=(int)$_POST["p14"];
        $p15=(int)$_POST["p15"];
        $p16=(int)$_POST["p16"];
        $p17=(int)$_POST["p17"];
        $p18=(int)$_POST["p18"];
        $p19=(int)$_POST["p19"];
        $p20=(int)$_POST["p20"];
        $p21=(int)$_POST["p21"];
        $p22=(int)$_POST["p22"];
        $p23=(int)$_POST["p23"];
        $p24=(int)$_POST["p24"];
        $pa=$p1+$p2+$p3+$p4+$p5+$p6+$p7+$p8;
        $pc=$p9+$p10+$p11+$p12+$p13+$p14+$p15+$p16;
        $pr=$p17+$p18+$p19+$p20+$p21+$p22+$p23+$p24;
        $n=$_POST["Rnom"];
        $c=$_POST["Rcor"];
        $s=$_POST["sex"];
        //atencion
        if($s=="masculino"){
            if($pa<21){
                $a="prestas poca atención";
            }elseif ($pa>33){
                $a="prestas demasiada atención";
            }else{
                $a="atención adecuada";
            }
        }else{
            if($pa<24){
                $a="prestas poca atención";
            }elseif ($pa>36){
                $a="prestas demasiada atención";
            }else{
                $a="atención adecuada";
            }
        }
        //claridad
        if($s=="masculino"){
            if($pc<25){
                $c="debes mejorar tu claridad";
            }elseif ($pc>36){
                $c="excelente claridad";
            }else{
                $c="atención adecuada";
            }
        }else{
            if($pc<23){
                $c="debes mejorar tu claridad";
            }elseif ($pa>35){
                $c="excelente claridad";
            }else{
                $c="atención adecuada";
            }
        }
        //Reparacion
        if($s=="masculino"){
            if($pr<23){
                $r="debes mejorar tu reparacion";
            }elseif ($pr>36){
                $r="excelente reparacion";
            }else{
                $r="atención adecuada";
            }
        }else{
            if($pr<23){
                $r="debes mejorar tu reparacion";
            }elseif ($pr>35){
                $r="excelente reparacion";
            }else{
                $r="atención adecuada";
            }
        }
        echo'</tr>
            <table>';
        $insertar = "INSERT INTO usuarios VALUES ('$n','$s','$c','$a','$c','$r')";
        $query = mysqli_query($conectar, $insertar);
        }
        
    }
    static public function resultados(){
        $host="localhost";
        $user ="root";
        $clave = "";
        $db = "test";
        $conexion=mysqli_connect($host,$user,$clave,$db);
        if(isset($_POST["nom"])){
            $name=$_POST["nom"];
            $sql="SELECT atencion FROM usuarios where nombre='".$name."';";
            $result=mysqli_query($conexion,$sql);
            echo"<table border=1>
                    <tr>
                        <td>Atencion:</td>";
            while ($mostrar=mysqli_fetch_array($result)) {
                echo "<td>".$mostrar['atencion']."</td> </tr>";
            }
            $sql="SELECT claridad FROM usuarios where nombre='".$name."';";
            $result=mysqli_query($conexion,$sql);
            while ($mostrar=mysqli_fetch_array($result)) {
                echo "<tr>
                        <td>Claridad: </td>
                        <td>".$mostrar['claridad']."</td> </tr>";
            }
            $sql="SELECT reparacion FROM usuarios where nombre='".$name."';";
            $result=mysqli_query($conexion,$sql);
            while ($mostrar=mysqli_fetch_array($result)) {
                echo "<tr>
                        <td>Reparacion: </td>
                        <td>".$mostrar['reparacion']."</td> </tr>";
            }
            echo"</table>";
            
        }
    }



}





?>