<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instrucciones</title>
</head>
<body>
    <h1>Instrucciones</h1>
    <p>Lea cuidadosamente cada frase incompleta y distribuya 
        10 puntos en los tres diferentes complementos. 
        Asigne más puntos al complemento con el que más se 
        identifique y menos a los demás:
    </p>

    <h2>Ejemplo</h2>
    <h3>Lo que mas deseo en la vida es llegar a...</h3>
    
    <ol type="A">
    <table  width="100%">
    <td width= "33%"    height= "50" ><li>Ser rico y famoso.</td></lI>
    <td width= "33%"  ><li> Ser apreciado por los demas.</td></li>
    <td width= "33%"  ><lI> Dedicarme a las bellas artes.</td></li>
        </table>
    </ol>

    <p>Puede utilizar cualquier combinación que sume 10 puntos. 
        Asegúrese de que no sean más ni menos de 10 puntos.
    </p>

    <h3>Este inventario no es un examen, ni hay respuestas buenas o malas, solo se busca que obtenga 
        información útil para su conocimiento. Por lo tanto es importante que cuando lo conteste sea 
        muy honesto y espontáneo. De igual manera, 
        tenga cuidado de responder de acuerdo con lo que realmente es y no como quisiera ser.
    </h3>

    <p>Una vez terminado el inventario, sume las columnas y traslade los totales 
        al diagrama de la motivación personal.</p>


    <a href="anexoA.php">Resolver Test</a>

</body>
</html>