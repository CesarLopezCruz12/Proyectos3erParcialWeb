<html>
	<head>
 <style>
input[type=text]{
  border:black 0px solid;
color: black;
}

li { 
  display: inline;
}

h1{
  font-size: 40px;

}

h2{
  font-size: 20px;
}

h3{ 
  font-size: 20px;
}

body{
  margin: 10px;  
 
}
input[type=text]{
  width: 6%;
  
}

input[type=submit]{
 
  width: 15%;
  height: 5%;
  color: cornsilk;
  background-color:gray ;
  border-bottom: 10px solid black;
  font-size: 20px;
}

div.boton {
  text-align: center;
}

  </style>
	</head>
	<body>

  
    <form method = "post" action="anexoB.php">
    <p><div id="p1">
    <h3>1. Me siento mejor con los demás cuando…</h3>
    <ul>
    <table  width="100%">
   
    <li>   <td width= "33%"    height= "50" >  A. Los dirijo (<input type="text" name="Puno1" id="Puno1"size ="1" required="" pattern="{0-10}">)</li></td>
    <li>  <td width= "33%"  >  B. Me aceptan (<input type="text"name="Puno2" id="Puno2"size ="1" required="" pattern="{0-10}">)</li></td>
    <li>  <td width= "33%" >  C. Aprendo algo de ellos (<input type="text" name="Puno3" id="Puno3" size ="1" required="" pattern="{0-10}">)</li></td>
   
    </table>
    </ul>
    </div></p>
   
    
  <p><div id="p2">
    <h3>2. Obtengo la mejor parte para mí siendo…</h3>
    <ul>  
    <table width="100%">
    <li> <td width= "33%" height= "50">  A.	Oportunista (<input type="text" name="Pdos1" id="Pdos1"size ="1" required="" pattern="{0-10}">)</li></td>
    <li><td width= "33%"  >  B.	Amistoso (<input type="text" name="Pdos2" id="Pdos2"size ="1" required="" pattern="{0-10}">)	</li></td>
    <li> <td width= "33%"> C.	Congruente conmigo (<input type="text" name="Pdos3" id="Pdos3" size ="1" required="" pattern="{0-10}">)</li></td>
  </div></p>
  </table>
  </ul>  


  <p><div id="p3">
    <h3>3. Me siento bien conmigo mismo cuándo…</h3>
    <ul>
    <table width="100%">
   
    <li>  <td width= "33%" height= "50">  A.	Busco ser líder (<input type="text" name="Ptres1" id="Ptres1"size ="1" required="" pattern="{0-10}">)</td></li>
    <li> <td width= "33%"  >    B.	Me adapto al grupo (<input type="text" name="Ptres2" id="Ptres2"size ="1" required="" pattern="{0-10}">)</td></li>
    <li> <td width= "33%" >    C.	Actúo por un ideal (<input type="text" name="Ptres3" id="Ptres3" size ="1" required="" pattern="{0-10}">) </td></li>
    
  </div></p>
    </table>
    </ul> 


    <p><div id="p4">
    <h3>4. Yo me esfuerzo más cuando…</h3>
    <ul>
    <table width="100%">
   
    <li><td width= "33%" height= "50">        A. Hay dinero de por medio (<input type="text" name="Pcuatro1" id="Pcuatro1"size ="1" required="" pattern="{0-10}">)</li></td>
    <li><td width= "33%"  >    B. Reconocen mi esfuerzo (<input type="text" name="Pcuatro2" id="Pcuatro2"size ="1" required="" pattern="{0-10}">)	</li></td>
    <li><td width= "33%" >     C. Me gusta lo que hay que hacer (<input type="text" name="Pcuatro3" id="Pcuatro3" size ="1" required="" pattern="{0-10}">) </li></td>
    </div></p>
    </table>
    </ul> 



    <p><div id="p5">
    <h3>5. Al relacionarme con otros pienso en…</h3>
    <ul>
    <table width="100%">
   
    <td width= "33%" height= "50">   <li> A. La influencia que tienen (<input type="text" name="Pcinco1" id="Pcinco1"size ="1" required="" pattern="{0-10}">)</li></td>
    <td width= "33%"  >    <li> B. En la confianza que me tienen (<input type="text" name="Pcinco2" id="Pcinco2"size ="1" required="" pattern="{0-10}">) </li></td>
    <td width= "33%" >     <li> C. En lo que significa para mi desarrollo (<input type="text" name="Pcinco3" id="Pcinco3" size ="1" required="" pattern="{0-10}">) </li></td>
    </div></p>
    </table>
    </ul> 


    <p><div id="p6">
    <h3>6.	Me da más miedo…</h3>
    <ul>
    <table width="100%">
    <td width= "33%" height= "50">   <li> A. La pobreza (<input type="text" name="Pseis1" id="Pseis1"size ="1" required="" pattern="{0-10}">)</li></td>
    <td width= "33%"   >    <li> B. La soledad (<input type="text" name="Pseis2" id="Pseis2"size ="1" required="" pattern="{0-10}">)		</li></td>
    <td width= "33%" >     <li> C. La falta de sentido de la vida (<input type="text" name="Pseis3" id="Pseis3" size ="1" required="" pattern="{0-10}">) </li></td>
    </div></p>
    </table>
    </ul> 


    <p><div id="p7">
    <h3>7.	Impresiono a otros presentándome como…</h3>
    <ul>
    <table width="100%">
    <td width= "33%" height= "50">   <li> A. Una persona astuta y audaz (<input type="text" name="Psiete1" id="Psiete1"size ="1" required="" pattern="{0-10}">)</li></td>
    <td width= "33%"   >    <li> B. Cariñosa y comprometida (<input type="text" name="Psiete2" id="Psiete2"size ="1" required="" pattern="{0-10}">)		</li></td>
    <td width= "33%" >     <li> C. Culta e inteligente (<input type="text" name="Psiete3" id="Psiete3" size ="1" required="" pattern="{0-10}">) </li></td>
    </div></p>
    </table>
    </ul> 


    <p><div id="p8">
    <h3>8.	Frente al fracaso yo…</h3>
    <ul>
    <table width="100%">
    <td width= "33%" height= "50">    <li> A. Me siento lesionado en mis derechos (<input type="text" name="Pocho1"  id="Pocho1"size ="1" required="" pattern="{0-10}">)</li></td>
    <td width= "33%"  >     <li> B. Busco consuelo en los demás (<input type="text" name="Pocho2" id="Pocho2"size ="1" required="" pattern="{0-10}">)		</li></td>
    <td width= "33%" >     <li> C. Busco una explicación que me ayude a mejorar(<input type="text" name="Pocho3" id="Pocho3" size ="1" required="" pattern="{0-10}">) </li></td>
    </div></p>
    </table>
    </ul> 


    <p><div id="p9">
    <h3>9.	Lo que más disfruto es (son)…</h3>
    <ul>
    <table width="100%">
    <td width= "33%" height= "50">    <li> A. Los éxitos económicos (<input type="text" name="Pnueve1" id="Pnueve1"size ="1" required="" pattern="{0-10}">)</li></td>
    <td width= "33%"  >     <li> B. La compañia de mi familia (<input type="text" name="Pnueve2" id="Pnueve2"size ="1" required="" pattern="{0-10}">)</li></td>
    <td width= "33%" >     <li> C. Los logros profesionales (<input type="text" name="Pnueve3" id="Pnueve3" size ="1" required="" pattern="{0-10}">) </li></td>
    </div></p>
    </table>
    </ul> 


    <p><div id="p10">

    <h3>10.	Para vencer las dificultades yo…</h3>
    <ul>
    <table width="100%">
  
    <td width= "33%" height= "50">   <li> A. Uso toda mi fuerza (<input type="text" name="Pdiez1" id="Pdiez1"size ="1" required="" pattern="{0-10}">)</li></td>
    <td width= "33%"  >    <li> B. Necesito ayuda de los demas (<input type="text" name="Pdiez2" id="Pdiez2"size ="1" required="" pattern="{0-10}">)		</li></td>
    <td width= "33%" >     <li> C. Apelo a mi formación interior (<input type="text" name="Pdiez3" id="Pdiez3" size ="1" required="" pattern="{0-10}">) </li>
    </div></p>
    </table>
    </ul> 


    <div class="boton">
	<input type="submit" value="Enviar" onclick="return todos()"/>
    </div>

  

<script type="text/javascript">
   function todos(){
   
   if(suma1()+suma2()+suma3()+suma4()+suma5()+suma6()+suma7()+suma8()+suma9()+suma10()==10){
   return true;
   }
   else{
  return false;
   }
}
    var suma1=function (P1num1, P1num2, P1num3 ){
     var P1num1 = parseFloat(document.getElementById("Puno1").value);
     var P1num2 = parseFloat(document.getElementById("Puno2").value);
     var P1num3 = parseFloat(document.getElementById("Puno3").value);  
    if ( P1num1+ P1num2+ P1num3==10){return 1;}
    else{alert("La pregunta 1 no suma 10"); return 0;}}

    var suma2=function (P2num1, P2num2, P2num3 ){
     var P2num1 = parseFloat(document.getElementById("Pdos1").value);
     var P2num2 = parseFloat(document.getElementById("Pdos2").value);
     var P2num3 = parseFloat(document.getElementById("Pdos3").value);  
    if ( P2num1+ P2num2+ P2num3==10){return 1;}
    else{alert("La pregunta 2 no suma 10"); return 0;}}

    var suma3=function (P3num1, P3num2, P3num3 ){
     var P3num1 = parseFloat(document.getElementById("Ptres1").value);
     var P3num2 = parseFloat(document.getElementById("Ptres2").value);
     var P3num3 = parseFloat(document.getElementById("Ptres3").value);  
    if ( P3num1+ P3num2+ P3num3==10){return 1;}
    else{alert("La pregunta 3 no suma 10"); return 0;}}

    var suma4=function (P4num1, P4num2, P4num3 ){
     var P4num1 = parseFloat(document.getElementById("Pcuatro1").value);
     var P4num2 = parseFloat(document.getElementById("Pcuatro2").value);
     var P4num3 = parseFloat(document.getElementById("Pcuatro3").value);  
    if ( P4num1+ P4num2+ P4num3==10){return 1;}
    else{alert("La pregunta 4 no suma 10"); return 0;}}

    var suma5=function (P5num1, P5num2, P5num3 ){
     var P5num1 = parseFloat(document.getElementById("Pcinco1").value);
     var P5num2 = parseFloat(document.getElementById("Pcinco2").value);
     var P5num3 = parseFloat(document.getElementById("Pcinco3").value);  
    if ( P5num1+ P5num2+ P5num3==10){return 1;}
    else{alert("La pregunta 5 no suma 10"); return 0;}}

    var suma6=function (P6num1, P6num2, P6num3 ){
     var P6num1 = parseFloat(document.getElementById("Pseis1").value);
     var P6num2 = parseFloat(document.getElementById("Pseis2").value);
     var P6num3 = parseFloat(document.getElementById("Pseis3").value);  
    if ( P6num1+ P6num2+ P6num3==10){return 1;}
    else{alert("La pregunta 6 no suma 10"); return 0;}}

    var suma7=function (P7num1, P7num2, P7num3 ){
     var P7num1 = parseFloat(document.getElementById("Psiete1").value);
     var P7num2 = parseFloat(document.getElementById("Psiete2").value);
     var P7num3 = parseFloat(document.getElementById("Psiete3").value);  
    if ( P7num1+ P7num2+ P7num3==10){return 1;}
    else{alert("La pregunta 7 no suma 10"); return 0;}}

    var suma8=function (P8num1, P8num2, P8num3 ){
     var P8num1 = parseFloat(document.getElementById("Pocho1").value);
     var P8num2 = parseFloat(document.getElementById("Pocho2").value);
     var P8num3 = parseFloat(document.getElementById("Pocho3").value);  
    if ( P8num1+ P8num2+ P8num3==10){return 1;}
    else{alert("La pregunta 8 no suma 10"); return 0;}}

    var suma9=function (P9num1, P9num2, P9num3 ){
     var P9num1 = parseFloat(document.getElementById("Pnueve1").value);
     var P9num2 = parseFloat(document.getElementById("Pnueve2").value);
     var P9num3 = parseFloat(document.getElementById("Pnueve3").value);  
    if ( P9num1+ P9num2+ P9num3==10){return 1;}
    else{alert("La pregunta 9 no suma 10"); return 0;}}

    var suma10=function (P10num1, P10num2, P10num3 ){
     var P10num1 = parseFloat(document.getElementById("Pdiez1").value);
     var P10num2 = parseFloat(document.getElementById("Pdiez2").value);
     var P10num3 = parseFloat(document.getElementById("Pdiez3").value);  
    if ( P10num1+ P10num2+ P10num3==10){return 1;}
    else{alert("La pregunta 10 no suma 10"); return 0;}}

    </script>
	</p>
  <a href="http://localhost/Proyecto_Final/Instrucciones.php"><button type="button" class="btn btn-secondary">Regresar al Men&uacute; de Test</button></a>

</body>
</html>



