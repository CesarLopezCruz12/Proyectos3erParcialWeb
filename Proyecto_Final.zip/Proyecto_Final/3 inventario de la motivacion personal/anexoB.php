<html>
<head>
<style>

p{
        font-size: 19px;

}
li {
  background-color: #F6E3CA;
  border: #D7C8B6 2px solid;
  display: inline;
  margin-right: 20px;
  
}
input[type=text]{

  color: black;
  background-color:beige ;
  
 
}

h3{
  background-color: #D7C8B6;
  font-size: 20px;
 
}
body{
  background-color: cornsilk;
 
}
input[type=text]{
  width: 3%;
  
}
input[type=submit]{
  
  width: 15%;
  height: 5%;
  color: cornsilk;
  background-color:gray ;
  border-bottom: 10px solid black;
  font-size: 20px;
}
div.boton {
  text-align: center;
}

        </style>        
</head>
<body>
    
<?php
$p1num1 = $_REQUEST['Puno1'];
$p1num2 = $_REQUEST['Puno2'];
$p1num3 = $_REQUEST['Puno3'];

$p2num1 = $_REQUEST['Pdos1'];
$p2num2 = $_REQUEST['Pdos2'];
$p2num3 = $_REQUEST['Pdos3'];

$p3num1 = $_REQUEST['Ptres1'];
$p3num2 = $_REQUEST['Ptres2'];
$p3num3 = $_REQUEST['Ptres3'];

$p4num1 = $_REQUEST['Pcuatro1'];
$p4num2 = $_REQUEST['Pcuatro2'];
$p4num3 = $_REQUEST['Pcuatro3'];

$p5num1 = $_REQUEST['Pcinco1'];
$p5num2 = $_REQUEST['Pcinco2'];
$p5num3 = $_REQUEST['Pcinco3'];

$p6num1 = $_REQUEST['Pseis1'];
$p6num2 = $_REQUEST['Pseis2'];
$p6num3 = $_REQUEST['Pseis3'];

$p7num1 = $_REQUEST['Psiete1'];
$p7num2 = $_REQUEST['Psiete2'];
$p7num3 = $_REQUEST['Psiete3'];

$p8num1 = $_REQUEST['Pocho1'];
$p8num2 = $_REQUEST['Pocho2'];
$p8num3 = $_REQUEST['Pocho3'];

$p9num1 = $_REQUEST['Pnueve1'];
$p9num2 = $_REQUEST['Pnueve2'];
$p9num3 = $_REQUEST['Pnueve3'];

$p10num1 = $_REQUEST['Pdiez1'];
$p10num2 = $_REQUEST['Pdiez2'];
$p10num3 = $_REQUEST['Pdiez3'];

$sumaA = $p1num1 + $p2num1 + $p3num1 + $p4num1 + $p5num1 + $p6num1 + $p7num1 + $p8num1 + $p9num1 + $p10num1;
$sumaB = $p1num2 + $p2num2 + $p3num2 + $p4num2 + $p5num2 + $p6num2 + $p7num2 + $p8num2 + $p9num2 + $p10num2;
$sumaC = $p1num1 + $p2num3 + $p3num3 + $p4num3 + $p5num3 + $p6num3 + $p7num3 + $p8num3 + $p9num3 + $p10num3;

if($sumaA > $sumaB &&$sumaA > $sumaB){
        $archivoA = "ABC.php";
    
    }
    if($sumaB > $sumaA&& $sumaB > $sumaC ){
      $archivoA = "ABC.php";
    
    }
    if($sumaC  > $sumaA && $sumaC  > $sumaB  ){
      $archivoA = "ABC.php";
    
    } 
    
    if($sumaC  == $sumaA || $sumaC  == $sumaB  ){
      $archivoA = "ABC.php";
    
    } 
    

?>


        <p> Suma columna:</p>
        <form method = "post" action="<?php echo "$archivoA";?>">
        <li> A <input type="text" name="A" id="A" size ="1" value="<?php echo "$sumaA";?> " required=""></li>
        <li> B <input type="text" name="B" id="B" size ="1" value="<?php echo "$sumaB";?> " required="" ></li>
        <li> C <input type="text" name="C" id="C" size ="1" value="<?php echo "$sumaC";?> " required="" ></li>
        <p></p>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['COLUMNA A - PODER', <?php echo "$sumaA";?> ],
          ['COLUMNA B - AFILIACIÓN', <?php echo "$sumaB";?> ],
          ['COLUMNA C - REALIZACIÓN PERSONAL',<?php echo "$sumaC";?> ]
        
        ]);

        var options = {
          title: 'Diagrama de la Motivación Personal'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }

    </script>
 <div id="piechart" style="width: 900px; height: 500px;"></div>



        <p>
        <div class="boton">      
        <input type="submit" value="Continuar" />
        </div>
</p>
</form>


</body>
</html>