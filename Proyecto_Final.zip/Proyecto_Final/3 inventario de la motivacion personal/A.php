<html>
<head></head>
<body>
<style>

body{
   background-color: DDF2F6;
}
h2{
   text-align: center;   
}
#columnas{
   column-count:2;
   column-gap:40px;
   column-rule:4px double gray;
   
}

</style>
<h2>Personas Motivadas por Poder (A)</h2>

<div id="columnas">
     <li>Trabajos que les permiten persuadir a la gente</li>
     <li>Responsabilidades que les permiten relacionarse con los directivos más altos</li>
     <li>Tareas que les da la oportunidad de enseñar</li>
     <li>Reconocimientos que tienen una base muy amplia (por ejemplo: utilizando los medios de comunicación) y que son visibles por personas que tienen influencia en la organización</li>
     <li>Nombramientos que reconocen sus logros y influencia en la organización</li>
     <li>Cartas a familiares enfatizando su impacto para beneficiar a la institución, los clientes, y la comunidad</li>
     <li>Trabajos que ofrecen mayor responsabilidad y autoridad</li>
     <li>Una descripción de trabajo y nombre de puesto que impresionan</li>
     <li>Notas personalizadas del supervisor y altos directivos agradeciendo su aportación para mejorar la comunidad y la condición humana</li>
     <li>Un programa que lleve su nombre</li>	
     <li>Oportunidad para aportar en el establecimiento de las metas organizacionales</li>
     <li>Oportunidad para innovar, cuestionar y debatir las decisiones</li>				
     <li>Permitir que sus ideas se expresen</li>
     <li>Presentarlas a personas con influencia</li>
     <li>Oportunidades para negociar</li>
     <li>Oportunidades para vender los servicios de la organización</li>
     <li>Tareas de gestión, con cuerpos legislativos y comités</li>
     <li>Compartiendo aspiraciones organizacionales</li>
     <li>Involucramiento en decisiones que afectan el futuro de la organización</li>
     <li>Contactos en el área de relaciones públicas y de los medios de comunicación</li>
     <li>Nombramientos en programas de la comunidad, del estado, o a nivel nacional</li>
     <li>Oportunidades para entrenar fuera de la organización</li>
     <li>Formar parte de mesas redondas y mesas de trabajo</li>
     <li>Usar como asesor</li>
     <li>Oportunidades para ser autor de algún artículo, libro o publicación</li>
     <li>Nombrar al consejo directivo de alguna institución</li>
     <li>Leovigildo</li>

</div>


</body>
</html>