<html>
<head></head>
<body>
<style>
body{
   background-color: DDF2F6;
}
h2{
   text-align: center;   
}
#columnas{
   column-count:2;
   column-gap:40px;
   column-rule:4px double gray;
   
}


</style>

<h2>Personas Motivadas por Afiliación (B)</h2>
<div id="columnas">
     <li>Reconocimiento en presencia de colegas y miembros de la familia</li>
     <li>Mención en el boletín o comunicación de la organización</li>
     <li>Su nombre y/o fotografía en un área pública de la organización</li>
     <li>Una nota personal enviada por el supervisor</li>
     <li>Un supervisor que recuerde el cumpleaños o un evento especial</li>
     <li>Oportunidades para socializar en su trabajo</li>
     <li>Trabajos que ofrecen oportunidades para interacción personal</li>
     <li>Oportunidades para aportar retroalimentación en temas sobre el personal de la organización</li>
     <li>Cartas a miembros de su familia agradeciendo que compartan el voluntario con la organización</li>
     <li>Cartas enviadas por clientes o por otras organizaciones de la comunidad</li>
     <li>Evaluaciones que miden el éxito junto con los talentos interpersonales</li>
     <li>Felicitarlas con sus amigos</li>
     <li>Expresiones de afecto y apreciación por su trabajo</li>
     <li>Compartir las necesidades de la organización a nivel personal</li>
     <li>Entrenamientos y capacitaciones personalizados en el trabajo</li>
     <li>Oportunidades de saludar, dar una introducción o bienvenida en eventos especiales</li>
</div>


</body>
</html>