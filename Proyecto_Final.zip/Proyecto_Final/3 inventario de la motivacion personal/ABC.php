<html>
<head></head>
<body>
<style>
body{
   background-color: white;
}
h2{
   text-align: center;   
}
#columnas{
   column-count:2;
   column-gap:40px;
   column-rule:4px double gray;
   
}


</style>

<h2>Personas Motivadas por Poder (A)</h2>
<div id="columnas">
     <li>Oportunidades para participar en decisiones acerca de metas</li>
     <li>Tener toda la responsabilidad delegada a ellos, y la habilidad de manejarla a su propio paso</li>
     <li>Oportunidad para crear ideas innovadoras y de lograr sus metas</li>
     <li>Exhibición en un área pública nombramientos, placas, y reconocimientos</li>
     <li>Cartas de recomendación y reconocimiento a sus jefes o a los periódicos locales por un trabajo específico</li>
     <li>Trabajos que tienen evaluaciones constantes para marcar éxitos</li>
     <li>Algún premio o reconocimiento por un programa específico</li>
     <li>Carta a los miembros de su familia informando sobre algún éxito específico</li>
     <li>Trabajos que ofrecen mayor responsabilidad</li>
     <li>Trabajos con metas muy claras y fáciles de medir</li>
     <li>Trabajos que ofrecen una oportunidad de superar un récord numérico (monetario, números de clientes servidos, récord de tiempo, etc.)</li>
     <li>Notas personalizadas del supervisor en reconocimiento de los logros</li>
     <li>Oportunidad de sentir que son una parte importante del total</li>
     <li>Capacitaciones que son interactivas</li>
     <li>Invitación para su participación en cómo la organización podría ser más eficiente</li>
     <li>Oportunidad para visitar e inspeccionar las instalaciones de la organización</li>
     <li>Cuidar que su tiempo no se desperdicie</li>
     <li>Informando con anticipación el orden del día de una junta o reunión</li>
     <li>Evaluaciones personales que miden el éxito y la realización de las metas</li>
     <li>Compartir las necesidades institucionales como reto</li>
     <li>Cartas por parte del consejo directivo, del personal administrativo felicitando triunfos específicos</li>
     <li>Oportunidades para cuestionar las decisiones</li>
     <li>Involucramiento en las decisiones que les afecten</li>
     <li>Honrar sus contribuciones a las metas</li>
     <li>Poner algún distintivo en su gafete indicando la antigüedad que tiene en la organización</li>
</div>

<h2>Personas Motivadas por Afiliación (B)</h2>
<div id="columnas">
     <li>Reconocimiento en presencia de colegas y miembros de la familia</li>
     <li>Mención en el boletín o comunicación de la organización</li>
     <li>Su nombre y/o fotografía en un área pública de la organización</li>
     <li>Una nota personal enviada por el supervisor</li>
     <li>Un supervisor que recuerde el cumpleaños o un evento especial</li>
     <li>Oportunidades para socializar en su trabajo</li>
     <li>Trabajos que ofrecen oportunidades para interacción personal</li>
     <li>Oportunidades para aportar retroalimentación en temas sobre el personal de la organización</li>
     <li>Cartas a miembros de su familia agradeciendo que compartan el voluntario con la organización</li>
     <li>Cartas enviadas por clientes o por otras organizaciones de la comunidad</li>
     <li>Evaluaciones que miden el éxito junto con los talentos interpersonales</li>
     <li>Felicitarlas con sus amigos</li>
     <li>Expresiones de afecto y apreciación por su trabajo</li>
     <li>Compartir las necesidades de la organización a nivel personal</li>
     <li>Entrenamientos y capacitaciones personalizados en el trabajo</li>
     <li>Oportunidades de saludar, dar una introducción o bienvenida en eventos especiales</li>
</div>

<h2>Personas Motivadas por Afiliación (C)</h2>
<div id="columnas">
     <li>Oportunidades para participar en decisiones acerca de metas</li>
     <li>Tener toda la responsabilidad delegada a ellos, y la habilidad de manejarla a su propio paso</li>
     <li>Oportunidad para crear ideas innovadoras y de lograr sus metas</li>
     <li>Exhibición en un área pública nombramientos, placas, y reconocimientos</li>
     <li>Cartas de recomendación y reconocimiento a sus jefes o a los periódicos locales por un trabajo específico</li>
     <li>Trabajos que tienen evaluaciones constantes para marcar éxitos</li>
     <li>Algún premio o reconocimiento por un programa específico</li>
     <li>Carta a los miembros de su familia informando sobre algún éxito específico</li>
     <li>Trabajos que ofrecen mayor responsabilidad</li>
     <li>Trabajos con metas muy claras y fáciles de medir</li>
     <li>Trabajos que ofrecen una oportunidad de superar un récord numérico (monetario, números de clientes servidos, récord de tiempo, etc.)</li>
     <li>Notas personalizadas del supervisor en reconocimiento de los logros</li>
     <li>Oportunidad de sentir que son una parte importante del total</li>
     <li>Capacitaciones que son interactivas</li>
     <li>Invitación para su participación en cómo la organización podría ser más eficiente</li>
     <li>Oportunidad para visitar e inspeccionar las instalaciones de la organización</li>
     <li>Cuidar que su tiempo no se desperdicie</li>
     <li>Informando con anticipación el orden del día de una junta o reunión</li>
     <li>Evaluaciones personales que miden el éxito y la realización de las metas</li>
     <li>Compartir las necesidades institucionales como reto</li>
     <li>Cartas por parte del consejo directivo, del personal administrativo felicitando triunfos específicos</li>
     <li>Oportunidades para cuestionar las decisiones</li>
     <li>Involucramiento en las decisiones que les afecten</li>
     <li>Honrar sus contribuciones a las metas</li>
     <li>Poner algún distintivo en su gafete indicando la antigüedad que tiene en la organización</li>
</div>


</body>
</html>